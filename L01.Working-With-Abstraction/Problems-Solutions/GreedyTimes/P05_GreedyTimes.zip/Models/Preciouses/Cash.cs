﻿namespace P05_GreedyTimes.Models
{
    public class Cash : Precious
    {
        public Cash(string cashType, int qtty) 
            : base(cashType, qtty)
        {
        }
    }
}
