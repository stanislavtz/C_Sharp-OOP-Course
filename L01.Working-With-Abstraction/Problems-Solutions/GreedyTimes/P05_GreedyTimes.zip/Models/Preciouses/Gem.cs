﻿namespace P05_GreedyTimes.Models
{
    public class Gem : Precious
    {

        public Gem(string gemType, int qtty)
            : base(gemType, qtty)
        {
        }
    }
}
