﻿namespace P05_GreedyTimes.Models
{
    public class Gold : Precious
    {
        public Gold(string goldType, int qtty) 
            : base(goldType, qtty)
        {
        }
    }
}
