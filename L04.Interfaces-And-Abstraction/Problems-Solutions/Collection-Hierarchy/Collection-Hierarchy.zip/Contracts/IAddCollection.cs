﻿namespace Collection_Hierarchy.Contracts
{
    public interface IAddCollection<T>
    {
        int Add(T element);
    }
}
