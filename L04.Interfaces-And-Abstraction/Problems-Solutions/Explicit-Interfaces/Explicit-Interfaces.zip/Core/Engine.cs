﻿using Explicit_Interfaces.Contracts;
using Explicit_Interfaces.Main;
using System;

namespace Explicit_Interfaces.Core
{
    public class Engine
    {
        public void Run()
        {
            string input = Console.ReadLine();

            while (input != "End")
            {
                string[] args = input.Split();

                string name = args[0];
                string country= args[1];
                int age = int.Parse(args[2]);

                IResident resident = new Citizen(name, country, age);
                IPerson person = new Citizen(name, country, age);

                Console.WriteLine(person.GetName());
                Console.WriteLine($"{resident.GetName()} {person.GetName()}");

                input = Console.ReadLine();
            }
        }
    }
}
