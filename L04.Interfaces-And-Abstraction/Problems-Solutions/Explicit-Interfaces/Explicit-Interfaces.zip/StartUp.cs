﻿using Explicit_Interfaces.Core;
using System;

namespace Explicit_Interfaces
{
    class Program
    {
        static void Main(string[] args)
        {
            var engine = new Engine();

            engine.Run();
        }
    }
}
