﻿namespace Military_Elite.Enumerators
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}
