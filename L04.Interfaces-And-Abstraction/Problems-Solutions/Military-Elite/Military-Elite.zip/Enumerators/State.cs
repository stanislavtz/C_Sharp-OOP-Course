﻿namespace Military_Elite.Enumerators
{
    public enum State
    {
        inProgress,
        Finished
    }
}
