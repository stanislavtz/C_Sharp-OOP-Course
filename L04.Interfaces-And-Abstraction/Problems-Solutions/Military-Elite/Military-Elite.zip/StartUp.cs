﻿using Military_Elite.Core;

namespace Military_Elite
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine();

            engine.Run();
        }
    }
}
